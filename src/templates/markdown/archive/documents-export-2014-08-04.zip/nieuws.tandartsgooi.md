NIEUWS
======


Graag informeren wij u over het volgende.

**Fusie Tandheelkundig Centrum ’t Gooi (THCG) en Tandartspraktijk Brediusweg (TB)**

Met genoegen en vol trots kondigen wij de fusie aan tussen Tandheelkundig Centrum ’t Gooi en Tandartspraktijk Brediusweg. Deze fusie betekent een bundeling van krachten en tandheelkundige expertise om u als patiënt de best mogelijke tandheelkundige zorg aan te kunnen bieden. 

De nieuwe praktijk gaat verder onder de naam Tandheelkundig Centrum ’t Gooi (TCG). De nieuwe groepspraktijk TCG zal gevestigd worden aan de Roemer Visscherlaan 1 te Bussum. (hoek Brediusweg) De locatie van THCG op de Nijverheidswerf is per 1 juni gesloten.

**Alle specialismen onder één dak**

Voor u als patiënt betekent dit dat u voortaan terecht kunt op de nieuwe locatie aan de Roemer Visscherlaan. Naast de algemene tandheelkundige zorg bieden wij op de nieuwe locatie ook gespecialiseerde zorg aan op het gebied van parodontologie(tandvleesproblemen), implantologie(titanium kunstwortels) en uitgebreide rehabilitaties. Er wordt gewerkt met de nieuwste apparatuur en technieken om u optimaal te kunnen behandelen.

**U bent van harte welkom**

Wij hopen u snel in onze nieuwe praktijk te mogen begroeten. Wij zijn ervan overtuigd met deze fusie een grote stap vooruit te zetten om u nog betere zorg te kunnen bieden.

**Vragen?**

Neem gerust contact op wanneer u vragen heeft over de fusie en wat dit voor u als patiënt betekend. U kunt ons bereiken op telefoonnummer 035-6913480. Graag tot ziens op de Roemer Visscherlaan 1.

 
Met vriendelijke groeten,

Het team van TCG