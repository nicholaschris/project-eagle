
CONTACT 
=======

Tandheelkundig Centrum ´t Gooi is centraal gelegen in Bussum, 5 minuten van de A1, en op loopafstand van NS station Naarden-Bussum. 

Wij verwelkomen u graag! Inschrijven kan online of telefonisch.



**Onze behandeltijden**
Maandag tot en met vrijdag van 07:30 en 16:30.

**Afspraken maken, verzetten of annuleren**
U kunt dagelijks telefonisch contact opnemen tussen 07:30 en 14:00. 

Bij spoedgevallen na 14:00 uur wordt u automatisch doorgeschakeld naar de spoedlijn van de praktijk. Telefoon: 035-6913480 / 035-6970700.
 
Annuleert u korter dan 24 uur voor de behandeltijd, dan worden kosten in rekening gebracht. Afspraken op maandag kunt u tot uiterlijk 12.00 uur op de vrijdag ervoor annuleren.

**Voor overige vragen kunt u onderstaand formulier gebruiken of telefonisch contact opnemen.**