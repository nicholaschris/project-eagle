
SPOEDHULP
==========

Bij acute (pijn)klachten heeft u direct hulp nodig. Hiervoor belt u op elke werkdag vóór 9.00 uur naar telefoonnummer 035-6913480 / 035-6970700.

Wij zullen u dan – zo mogelijk – nog dezelfde dag helpen. Een voorwaarde is wel dat u uw gebit tweemaal per jaar laat controleren en dat vervolgbehandelingen binnen een maand plaatsvinden. Zo willen we pijnklachten voorkomen.
 
**Avond- of weekenddienst**
Heeft u tijdens de avonduren of weekenden spoedeisende hulp nodig, bijvoorbeeld na een ongeval of een nabloeding? Bel dan met de **Centrale Doktersdienst** (0900-1515). Daar vertellen ze u welke tandarts dienst heeft.

De dienstdoende tandarts beperkt zich tot het bieden van eerste hulp. Voor eventuele vervolgbehandelingen verwijst hij/zij u weer terug naar ons.

Tijdens de weekenddienst/avonddienst wordt een behandeling altijd contant afgerekend. U ontvangt daarvoor een kwitantie die u kunt indienen bij uw zorgverzekeraar.

**Avonddienst**: maandag tot en met donderdag van 18.00 uur tot 8.00 uur.

**Weekenddienst**: vrijdagochtend 8.00 uur tot en met maandagochtend 8.00 uur.

Het telefoonnummer van de **Centrale Doktersdienst** is 0900-1515.
