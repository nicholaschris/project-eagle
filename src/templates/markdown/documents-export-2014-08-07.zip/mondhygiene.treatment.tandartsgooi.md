
###Mondhygiëne
Regelmatige controle en preventieve behandelingen houden uw gebit en tandvlees in optimale conditie. Onze tandartsen en preventie-assistentes vertellen u ook hoe u uw mond zelf gezond en fris kunt houden. Zij werken in teamverband voor het beste resultaat. In overleg met u stemmen zij onderling uw behandelingen op elkaar af. Handig.

####Voorkomen is beter dan genezen

Het melkgebit is meestal al compleet vanaf 1 of 2 jaar. Vanaf dat moment is regelmatige gebitscontrole zeer aan te raden. Dat geldt zeker in de volgende gevallen:

- als u problemen wilt voorkomen en zelf wilt werken aan een gezonde en frisse mond
- als u tandsteen of aanslag op uw gebit heeft
- als u regelmatig nieuwe gaatjes krijgt
- als u wel eens last heeft van bloedend tandvlees
- als u regelmatig een slechte adem heeft
- als u gevoelige tandhalzen of teruggetrokken tandvlees heeft

