
###Frisse adem

De meeste mensen met een slechte adem (halitose) merken dat zelf niet. Hun omgeving des te meer. Iemand met halitose ruikt niet eenmalig uit zijn mond (bijvoorbeeld door gekruid eten, of alcohol) maar altijd. 

De belangrijkste boosdoener is de aanwezigheid van bacteriën en voedselresten op het achterste gedeelte van de tong. De bacteriën produceren zwavel en dat ruikt onaangenaam. Halitose gaat niet vanzelf voorbij, maar is in de meeste gevallen eenvoudig te verhelpen door de tandarts of mondhygiëst.

####Tips voor een frisse adem
- Poets de tanden tweemaal per dag met fluoridetandpasta.
- Reinig de ruimten tussen tanden en kiezen eenmaal per dag met flossdraad, tandenstokers of ragers.
- Gebruik tweemaal per dag een tongschraper als u veel tongbeslag heeft.
- Ga regelmatig voor controle naar uw tandarts of mondhygiënist. Die zal zo nodig uw gebit grondig reinigen.