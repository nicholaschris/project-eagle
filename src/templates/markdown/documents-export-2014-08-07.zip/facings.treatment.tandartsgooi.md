
###Facings

Met facings kan de tandarts het uiterlijk van uw gebit verfraaien, zoals de vorm of kleur van een tand. 

Een facing is een laagje tandkleurig vulmateriaal van composiet, of een schildje van porselein. De tandarts plakt de facing op de tand. Ook kan hij spleetjes tussen tanden opvullen, afgebroken hoekjes repareren, gele of bruine tanden weer wit maken en scheve tanden maskeren.

####Levensduur
Een facing gaat vijf tot tien jaar mee. Het kan slijten of beschadigen maar gelukkig valt dat altijd te reperaren, zonder dat de tand zelf beschadigt.

####Kosten
De kosten van een facing hangen vooral af van het gebruikte materiaal. Een facing van composiet is aanzienlijk goedkoper dan een facing van porselein. 

Een facing van composiet komt tijdens de behandeling direct in de mond tot stand. Een facing van porselein wordt eerst in het tandtechnisch laboratorium door een tandtechnicus vervaardigd, waardoor er kosten bijkomen.

