###Bleken

Tandheelkundig Centrum 't Gooi maakt gebruik van *Philips Zoom! Whitening Technologie*. Met dit systeem zijn uw tanden in ongeveer een uur aanzienlijk witter.

De behandeling is eenvoudig. Eerst worden uw lippen en tandvlees afgedekt, zodat alleen uw tanden nog zichtbaar zijn. Vervolgens wordt de *Zoom!* gel op uw tanden aangebracht. Deze gel is ontwikkeld voor gebruik in combinatie met een speciaal ontworpen lamp. De gel en lamp versterken elkaar in het afbreken van de vlekken en verkleuringen op uw tanden. Met een goede mondhygiëne kunt u hierna nog jaren genieten van uw nieuwe lach.

U kunt het beste een afspraak voor een gebitsreiniging maken en daar vervolgens laten controleren of u in aanmerking komt voor professioneel tanden bleken.
